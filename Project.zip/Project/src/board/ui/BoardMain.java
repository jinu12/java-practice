package board.ui;

public class BoardMain {

	public static void main(String[] args) {
		BoardUI ui = new BoardUI();
		
	}

}
