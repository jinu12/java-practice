package Vote.vo;

//�Խ��� �� ���� VO
public class Vote_user {
	private int boardnum;		//�Խñ� �Ϸù�ȣ
	private String name;		//�ۼ��� �̸�
	private String title;		//������
	private String content;		//�۳���
	private int hits;			//��ȸ��
	private String indate;		//�ۼ���
	
	public int getBoardnum() {
		return boardnum;
	}
	public void setBoardnum(int boardnum) {
		this.boardnum = boardnum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getHits() {
		return hits;
	}
	public void setHits(int hits) {
		this.hits = hits;
	}
	public String getIndate() {
		return indate;
	}
	public void setIndate(String indate) {
		this.indate = indate;
	}
	
	
	
}
