package Vote.ui;

public class VoteMain {

	public static void main(String[] args) {
		VoteUI ui = new VoteUI();
	}

}
